#include <stdio.h>

int main(int ac, char** av)
{
    printf("Whoa! Hello big wide wonderful world\n");
    return 1;
}
